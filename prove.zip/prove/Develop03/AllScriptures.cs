// public class AllScriptures
// {
//   List<Scripture> _scriptures = new List<Scripture>();
// }