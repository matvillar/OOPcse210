public class Breathing : ActivityStructure
{

  public Breathing( string activityName, string activityDescription) : base(activityName, activityDescription)
  {

   

  }



  
}