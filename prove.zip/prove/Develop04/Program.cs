using System;

class Program
{
    static void Main(string[] args)

    {
    Menu menu = new Menu();
    menu.Display();
      // ActivityStructure activityStructure = new ActivityStructure("Develop04", "a simple program that uses a class");
      // activityStructure.WelcomeMessage();
      //   activityStructure.CountDown();
    }
}